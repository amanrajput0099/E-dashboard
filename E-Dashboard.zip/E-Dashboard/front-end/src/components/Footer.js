import React  from "react";

const Footer=()=>{
    return (
        <div className="footer">
            <h1> E-comm Dashboard</h1>
        </div>
    )
}
export default Footer;